#include "headers/accounts.h"

void create_account(char username, char password, int id) {
    FILE *database;

    Account new_account = {
        .username = username,
        .password = password,
        .id = id
    };

    if (database = fopen('database.txt', 'w') < 0) {
        printf("Error: unable to open file.");
        exit(1);
    }
    
    fprintf(database, "%s:%s:%d", new_account.username, new_account.password, new_account.id);
    fclose(database);
}