#pragma once

#include "main.h"

typedef struct {
    char username[20];
    char password[64];
    int id[5];
} Account;

extern void create_account(char username, char password, int id);