#pragma once
#include <netinet/in.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

#include "accounts.h"
#include "utils.h"

extern string username[24];
extern string password[64];

extern ssize_t fdgets(unsigned char *buffer, size_t bufferSize, int fd) {
    ssize_t total = 0, got;

    if (bufferSize == 0) 
        return 0;

    while (total < bufferSize - 1) {
        got = read(sockfd, buffer + total, 1);

        if (got <= 0) 
            return (got == 0 && total > 0) ? total : -1;

        if (buffer[total++] == '\n') 
            break;
    }
    buffer[total] = '\0';
    return total;
}

