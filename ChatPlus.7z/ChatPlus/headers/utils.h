#pragma once

#include "main.h"

#define MAX_SESSIONS 512

extern int create_and_bind(int port, char address);

// define externally variables to be referenced.
extern struct sockaddr_in my_addr;
extern char bind_verify;
extern int new_sock;
extern int sockfd;
extern int opt;
