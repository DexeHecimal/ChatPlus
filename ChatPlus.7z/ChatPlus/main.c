#include "headers/main.h"

void user_loop(int port, char address) {
    if (create_and_bind(port, address) < 0) {
        printf("Error: create_and_bind() failed!\n");
        exit(EXIT_FAILURE);
    }

    if (listen_and_accept(port, address) < 0) {
        printf("Error: listen_and_accept() failed!\n");
        exit(EXIT_FAILURE);
    }

    while(1) {
        Login:
            if (send(new_sock, "Please Login!\nusername: \npassword: \n", 36, MSG_NOSIGNAL) == -1)
                goto FailedLogin;
        
        FailedLogin:
            if (send(new_sock, "Login failed!\ninvalid credentials specified...\n", 47, MSG_NOSIGNAL) == -1) {
                /* 
                    need to design asynchronus concurrent connection management 
                    for killing client specified fds and tracking these transactions. 

                    Going to bed, continued work will resume tomorrow. (6/24/2024) 2:00am EDT.
                */
            }
    }
}

int main(int argc, char **args) {
    if (argc < 3) {
        printf("Error: missing parameters!\nExample usage: %s [port] [address] [threads]\n");
        exit(1);
    }

    user_loop(atoi(args[1]), atoi(args[2]));
    return 0;
}
